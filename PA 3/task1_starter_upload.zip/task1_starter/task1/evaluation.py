"""Evaluate checkpoint copies; never change the weights or RNG of a training process."""
import gc
import time
from pathlib import Path

import torch
from lm_eval import simple_evaluate
from lm_eval.models.huggingface import HFLM

from .common import read_jsonl, write_json, write_jsonl
from .data import qualitative_inputs
from .model import (LowRankLinear, attach_adapters, load_base, load_tokenizer,
                    merge_into_fresh, restore_trainable, seed_all)


class LoggedHFLM(HFLM):
    """Use stock scoring/stopping, but retain raw generation lengths and cap flags."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.generation_records = {}
        self.current_doc = None

    def generate_until(self, requests, disable_tqdm=False):
        # Batch one for traceability. Candidate-likelihood tasks still use normal batching.
        answers = []
        for request in requests:
            self.current_doc = int(request.doc_id)
            answers.extend(super().generate_until([request], disable_tqdm=True))
        return answers

    def _model_generate(self, context, max_length, stop, **kwargs):
        tokens = super()._model_generate(context, max_length, stop, **kwargs)
        continuation = tokens[0, context.shape[1]:].tolist()
        raw = self.tokenizer.decode(continuation, skip_special_tokens=False)
        eos = self.model.generation_config.eos_token_id
        eos = set(eos if isinstance(eos, list) else [eos])
        stopped = (bool(continuation) and continuation[-1] in eos) or any(s and s in raw for s in stop)
        self.generation_records[self.current_doc] = {
            "generated_tokens": len(continuation),
            "hit_token_cap": tokens.shape[1] >= max_length,
            "truncated": tokens.shape[1] >= max_length and not stopped,
            "raw_response": raw,
        }
        return tokens


def evaluation_model(c, root, method, update):
    tokenizer = load_tokenizer(root)
    if method == "baseline":
        return load_base(c, root).eval(), tokenizer
    run = Path(root) / "runs" / method
    if method in ("full_ft", "l2sp"):
        model = load_base(c, root)
        state = torch.load(run / "checkpoints" / f"update_{update:04d}.pt", map_location="cpu", weights_only=False)
        restore_trainable(model, state["model"])
        del state
        return model.eval(), tokenizer

    exports = torch.load(run / f"adapters_{update:04d}.pt", weights_only=True)
    # Check the exported effective (already projected) factors against their merged form.
    unmerged = attach_adapters(load_base(c, root), "lora4" if method == "lora4" else "lora16", c, root)
    with torch.no_grad():
        for name, item in exports.items():
            module = unmerged.get_submodule(name)
            module.A.copy_(item["A"].to("cuda"))
            module.B.copy_(item["B"].to("cuda"))
    unmerged.eval()
    merged = merge_into_fresh(load_base(c, root), exports).eval()
    probe_rows = read_jsonl(Path(root) / "prepared/probes.jsonl")
    differences = []
    relative = []
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
        # Math and non-math prompts, using actual exported factors.
        for row in [probe_rows[0], probe_rows[-1]]:
            inputs = tokenizer(row["prompt"], return_tensors="pt", add_special_tokens=False).to("cuda")
            a = unmerged(**inputs, logits_to_keep=1).logits[:, -1].float()
            b = merged(**inputs, logits_to_keep=1).logits[:, -1].float()
            differences.append((a - b).abs().max().item())
            relative.append(((a - b).norm() / (a.norm() + 1e-8)).item())
    destination = Path(root) / "evaluations" / f"{method}_{update:04d}"
    write_json(destination / "merge_check.json", {
        "max_abs_logit_differences": differences, "relative_l2_errors": relative,
        "relative_l2_tolerance": 0.02,
        "note": "FP16 merge changes rounding; inspect saved errors as well as threshold.",
    })
    if max(relative) > 0.02:
        raise ValueError("Merged/unmerged logits differ substantially. Inspect merge_check.json.")
    del unmerged, exports
    gc.collect()
    torch.cuda.empty_cache()
    return merged, tokenizer


def evaluate(c, root, method, update, smoke=False):
    seed_all(c["seed"])
    destination = Path(root) / "evaluations" / f"{method}_{update:04d}"
    destination.mkdir(parents=True, exist_ok=True)
    if (destination / "complete.json").exists():
        return
    started = time.perf_counter()
    model, tokenizer = evaluation_model(c, root, method, update)
    model.config.use_cache = True
    if not smoke and method != "baseline":
        export = Path(root) / "models" / f"{method}_{update:04d}"
        # Save ordinary Hugging Face models so downloads do not require recovery
        # optimizer states or this custom adapter implementation for inference.
        model.save_pretrained(export, safe_serialization=True)
        tokenizer.save_pretrained(export)
        write_json(export / "export_complete.json", {
            "method": method, "update": update, "dtype": "float16",
            "format": "standalone Hugging Face model; projected adapters already merged",
        })
    wrapper = LoggedHFLM(
        pretrained=model, tokenizer=tokenizer, batch_size=c["eval_batch_size"],
        enable_thinking=False, max_length=model.config.max_position_embeddings,
    )
    all_scores = {}
    expected = {"gsm8k_cot": 1319, "hellaswag": 10042, "boolq": 3270, "arc_easy": 2376}
    for tasks, chat in [(["gsm8k_cot"], True), (["hellaswag", "boolq", "arc_easy"], False)]:
        kwargs = dict(
            model=wrapper, tasks=tasks, num_fewshot=0, batch_size=c["eval_batch_size"],
            apply_chat_template=chat, log_samples=True,
            random_seed=c["seed"], numpy_random_seed=c["seed"],
            torch_random_seed=c["seed"], fewshot_random_seed=c["seed"],
            limit=2 if smoke else None,
        )
        if chat:
            kwargs["gen_kwargs"] = "max_gen_toks=32,do_sample=False" if smoke else "max_gen_toks=1024,do_sample=False"
        result = simple_evaluate(**kwargs)
        if result is None:
            raise RuntimeError("Evaluation harness returned no results.")
        for task, samples in result.pop("samples").items():
            doc_ids = {row["doc_id"] for row in samples}
            if not smoke and len(doc_ids) != expected[task]:
                raise ValueError(f"{task}: expected complete split ({expected[task]}), got {len(doc_ids)}")
            if task == "gsm8k_cot":
                for row in samples:
                    row.update(wrapper.generation_records[int(row["doc_id"])])
                    # Stock filtered_resps is the authoritative extracted answer.
                    row["extracted_answer"] = row.get("filtered_resps")
            write_jsonl(destination / f"{task}_samples.jsonl", samples)
        all_scores.update(result["results"])
        write_json(destination / ("harness_math.json" if chat else "harness_retention.json"), result)
    write_json(destination / "scores.json", {
        "method": method, "update": update, "smoke_only": smoke, "results": all_scores,
    })

    qualitative = []
    for row in qualitative_inputs(c):
        prompt = tokenizer.apply_chat_template(
            row["messages"], tokenize=False,
            add_generation_prompt=True, enable_thinking=False,
        )
        inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False).to("cuda")
        cap = 32 if smoke else 512
        with torch.inference_mode():
            tokens = model.generate(**inputs, do_sample=False, max_new_tokens=cap,
                                    pad_token_id=tokenizer.pad_token_id)
        continuation = tokens[0, inputs.input_ids.shape[1]:].tolist()
        eos = model.generation_config.eos_token_id
        eos = set(eos if isinstance(eos, list) else [eos])
        qualitative.append({**row, "condition": f"{method}_{update:04d}",
                            "response": tokenizer.decode(continuation, skip_special_tokens=True),
                            "generated_tokens": len(continuation),
                            "truncated": len(continuation) >= cap and continuation[-1] not in eos})
    write_jsonl(destination / "qualitative.jsonl", qualitative)
    write_json(destination / "complete.json", {
        "evaluation_seconds": time.perf_counter() - started, "smoke_only": smoke,
    })
