"""The actual epoch: read batches -> forward -> backward -> update -> log -> save."""
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
from transformers import get_cosine_schedule_with_warmup

from .common import append_csv, read_json, read_jsonl, stages, write_json
from .data import collate
from .model import (adapter_exports, attach_adapters, load_base, load_tokenizer,
                    restore_trainable, seed_all, trainable_state)


def rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(), "cuda": torch.cuda.get_rng_state_all()}


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    torch.cuda.set_rng_state_all(state["cuda"])


def save_checkpoint(path, model, optimizer, scheduler, scaler, update, totals, method):
    path.parent.mkdir(parents=True, exist_ok=True)
    def cpu_copy(value):
        if isinstance(value, torch.Tensor):
            return value.detach().cpu()
        if isinstance(value, dict):
            return {k: cpu_copy(v) for k, v in value.items()}
        if isinstance(value, list):
            return [cpu_copy(v) for v in value]
        return value
    state = {"model": trainable_state(model), "optimizer": cpu_copy(optimizer.state_dict()),
             "scheduler": scheduler.state_dict(), "scaler": scaler.state_dict(),
             "rng": rng_state(), "update": update, "totals": totals, "method": method}
    temporary = path.with_suffix(".tmp")
    torch.save(state, temporary)
    temporary.replace(path)
    return path.stat().st_size


def latest_checkpoint(directory):
    paths = sorted(Path(directory).glob("update_*.pt"))
    return paths[-1] if paths else None


def proximity(model, reference):
    # named_parameters removes duplicates: tied embedding/head weights count once.
    penalty = torch.zeros((), device="cuda", dtype=torch.float32)
    transfer_seconds = 0.0
    with torch.autocast("cuda", enabled=False):
        for name, parameter in model.named_parameters():
            before = time.perf_counter()
            initial = reference[name].to(parameter.device)
            torch.cuda.synchronize()
            transfer_seconds += time.perf_counter() - before
            penalty = penalty + 0.5 * (parameter.float() - initial).square().sum()
    return penalty, transfer_seconds


@torch.no_grad()
def displacement(model, reference):
    return math.sqrt(sum((p.detach().float().cpu() - reference[n]).square().sum().item()
                         for n, p in model.named_parameters()))


def train(c, root, method, stop_update):
    root = Path(root)
    run = root / "runs" / method
    run.mkdir(parents=True, exist_ok=True)
    total_updates = c["examples"] // (c["microbatch"] * c["accumulation"])
    adapter = method.startswith("lora") or method == "oplora16"
    checkpoint = latest_checkpoint(run / "checkpoints")
    expected_artifacts = [run / "resources.json"]
    if adapter:
        expected_artifacts += [run / f"adapters_{stop_update:04d}.pt", run / f"export_{stop_update:04d}.json"]
    elif stop_update == total_updates or method == "full_ft":
        expected_artifacts += [run / f"displacement_{stop_update:04d}.json"]
    if checkpoint and int(checkpoint.stem.split("_")[-1]) >= stop_update and all(p.exists() for p in expected_artifacts):
        print(f"{method}: training already reached update {stop_update}; keeping saved state.")
        return
    target_checkpoint = run / "checkpoints" / f"update_{stop_update:04d}.pt"
    if target_checkpoint.exists():
        checkpoint = target_checkpoint  # Recover missing exports/evidence from this exact state.
    seed_all(c["seed"])
    tokenizer = load_tokenizer(root)
    model = load_base(c, root, dtype=torch.float16 if adapter else torch.float32)
    reference = None
    reference_seconds = 0.0
    if not adapter:
        before = time.perf_counter()
        reference = {n: p.detach().float().cpu().clone() for n, p in model.named_parameters()}
        reference_seconds = time.perf_counter() - before
    else:
        attach_adapters(model, method, c, root)
    model.config.use_cache = False
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.train()
    parameters = [p for p in model.parameters() if p.requires_grad]
    named = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
    decay = [p for n, p in named if p.ndim >= 2 and not n.endswith("bias")]
    no_decay = [p for n, p in named if p.ndim < 2 or n.endswith("bias")]
    optimizer = torch.optim.AdamW([
        {"params": decay, "weight_decay": c["weight_decay"]},
        {"params": no_decay, "weight_decay": 0.0},
    ], lr=2e-4 if adapter else 2e-5, betas=(0.9, 0.999), eps=1e-8, foreach=False)
    scheduler = get_cosine_schedule_with_warmup(optimizer, c["warmup_updates"], total_updates)
    scaler = torch.amp.GradScaler("cuda")
    totals = {"training_seconds": 0.0, "peak_gpu_bytes": 0, "skipped_updates": 0,
              "reference_transfer_seconds": 0.0, "checkpoint_seconds": 0.0}
    start = 0
    if checkpoint:
        # Only load this project's trusted local checkpoints: they contain RNG state.
        saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
        restore_trainable(model, saved["model"])
        optimizer.load_state_dict(saved["optimizer"])
        scheduler.load_state_dict(saved["scheduler"])
        scaler.load_state_dict(saved["scaler"])
        restore_rng(saved["rng"])
        start, totals = saved["update"], saved["totals"]
        metrics_path = checkpoint.with_suffix(".metrics.json")
        if metrics_path.exists():
            totals = read_json(metrics_path)
        del saved
    totals["reference_setup_seconds"] = totals.get("reference_setup_seconds", 0.0) + reference_seconds
    # A crash may leave log rows beyond the last recoverable optimizer update.
    # Preserve those separately, then roll the active learning curve back to the checkpoint.
    from .plots import csv_rows, save_table
    history = csv_rows(run / "training.csv")
    interrupted = [row for row in history if int(row["update"]) > start]
    if interrupted and start < stop_update:
        save_table(run / f"interrupted_after_{start:04d}.csv", interrupted)
        retained = [row for row in history if int(row["update"]) <= start]
        if retained:
            save_table(run / "training.csv", retained)
        else:
            (run / "training.csv").unlink()
    rows = read_jsonl(root / "prepared/training.jsonl")
    effective_batch = c["microbatch"] * c["accumulation"]
    if len(rows) != c["examples"]:
        raise ValueError("Prepared training set size changed.")
    torch.cuda.reset_peak_memory_stats()
    trainable_count = sum(p.numel() for p in parameters)
    reference_bytes = sum(x.numel() * x.element_size() for x in reference.values()) if reference else 0
    basis_bytes = sum(b.numel() * b.element_size() for n, b in model.named_buffers()
                      if n.endswith((".U", ".V")))

    def publish_checkpoint_evidence(update, size):
        if adapter:
            export_before = time.perf_counter()
            torch.save(adapter_exports(model), run / f"adapters_{update:04d}.pt")
            write_json(run / f"export_{update:04d}.json", {
                "seconds": time.perf_counter() - export_before,
                "bytes": (run / f"adapters_{update:04d}.pt").stat().st_size,
            })
        if not adapter and (update == total_updates or (method == "full_ft" and update == total_updates // 2)):
            write_json(run / f"displacement_{update:04d}.json", {
                "l2_displacement": displacement(model, reference),
            })
        write_json(run / "resources.json", {
            **totals, "method": method, "trainable_parameters": trainable_count,
            "reference_bytes_cpu": reference_bytes, "reference_setup_seconds_this_process": reference_seconds,
            "protection_basis_bytes_gpu": basis_bytes,
            "trainable_state_bytes": sum(p.numel() * p.element_size() for p in parameters),
            "last_checkpoint_bytes": size, "last_update": update,
            "gpu": torch.cuda.get_device_name(),
            "timing_note": "Training excludes checkpoint/evaluation/plotting; these are logged separately.",
        })

    if start >= stop_update:
        publish_checkpoint_evidence(start, checkpoint.stat().st_size)
        return

    for update in range(start + 1, stop_update + 1):
        before = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        offset = (update - 1) * effective_batch
        batch_rows = rows[offset:offset + effective_batch]
        # Correct token weighting: sum CE over ALL response tokens / their total count.
        # Averaging microbatch means would over-weight short responses.
        valid_tokens = sum(sum(t != -100 for t in row["labels"][1:]) for row in batch_rows)
        sft_loss = 0.0
        used_lr = optimizer.param_groups[0]["lr"]
        for micro_start in range(0, len(batch_rows), c["microbatch"]):
            batch = collate(batch_rows[micro_start:micro_start + c["microbatch"]], tokenizer.pad_token_id)
            batch = {k: v.to("cuda") for k, v in batch.items()}
            count = (batch["labels"][:, 1:] != -100).sum()
            with torch.autocast("cuda", dtype=torch.float16):
                output = model(**batch)
                weighted_loss = output.loss * (count / valid_tokens)
            scaler.scale(weighted_loss).backward()
            sft_loss += weighted_loss.detach().item()
            del output, weighted_loss, batch
        omega, transfer_seconds = 0.0, 0.0
        if method == "l2sp":
            penalty, transfer_seconds = proximity(model, reference)
            omega = penalty.detach().item()
            scaler.scale(c["lambda_sp"] * penalty).backward()
            del penalty
        # AMP gradients must be unscaled BEFORE clipping.
        scaler.unscale_(optimizer)
        grad_norm = torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        old_scale = scaler.get_scale()
        scaler.step(optimizer)
        scaler.update()
        skipped = scaler.get_scale() < old_scale
        if not skipped:
            scheduler.step()
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - before
        totals["training_seconds"] += elapsed
        totals["reference_transfer_seconds"] += transfer_seconds
        totals["skipped_updates"] += int(skipped)
        totals["peak_gpu_bytes"] = max(totals["peak_gpu_bytes"], torch.cuda.max_memory_allocated())
        append_csv(run / "training.csv", {
            "update": update, "examples_seen": update * effective_batch,
            "response_tokens": valid_tokens, "sft_loss": sft_loss,
            "omega": omega, "weighted_penalty": c["lambda_sp"] * omega,
            "total_loss": sft_loss + c["lambda_sp"] * omega, "lr": used_lr,
            "grad_norm": float(grad_norm), "amp_scale": scaler.get_scale(),
            "skipped": int(skipped), "seconds": elapsed,
        })
        if update == 1 or update % c["plot_every"] == 0 or update == stop_update:
            print(f"{method}: {update}/{total_updates}  SFT={sft_loss:.4f}  {elapsed:.2f}s/update", flush=True)
            from .plots import refresh
            refresh(root)
        if update in stages(c) or update == stop_update:
            checkpoint_before = time.perf_counter()
            cp = run / "checkpoints" / f"update_{update:04d}.pt"
            size = save_checkpoint(cp, model, optimizer, scheduler, scaler, update, totals, method)
            totals["checkpoint_seconds"] += time.perf_counter() - checkpoint_before
            # The duration of writing a checkpoint is only known AFTER that write.
            # Preserve it separately so a midpoint resume does not lose this overhead.
            write_json(cp.with_suffix(".metrics.json"), totals)
            publish_checkpoint_evidence(update, size)
