"""Evaluate checkpoint copies; never change the weights or RNG of a training process."""
import gc
import hashlib
import json
import time
from pathlib import Path

import torch
from lm_eval.models.huggingface import HFLM

from .common import read_jsonl, write_json, write_jsonl
from .data import qualitative_inputs
from .model import (LowRankLinear, attach_adapters, load_base, load_tokenizer,
                    merge_into_fresh, restore_trainable, seed_all)


class LoggedHFLM(HFLM):
    """Use stock scoring/stopping, but retain raw generation lengths and cap flags."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.generation_records = {}
        self.current_doc = None

    def generate_until(self, requests, disable_tqdm=False):
        # Batch one for traceability. Candidate-likelihood tasks still use normal batching.
        # Cache each completed answer, not just an entire finished benchmark.
        path = getattr(self, "generation_cache_path", None)
        cache = {}
        if path and Path(path).exists():
            contents = Path(path).read_text(encoding="utf-8")
            lines = contents.splitlines()
            for index, line in enumerate(lines):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    if index != len(lines) - 1:
                        raise ValueError("Generation cache is corrupted before its final line.")
                    # Preserve a crash-interrupted final record separately before repairing.
                    Path(str(path) + ".interrupted").write_text(line, encoding="utf-8")
                    Path(path).write_text("\n".join(lines[:-1]) + "\n", encoding="utf-8")
                    continue
                cache[record["key"]] = record
            if contents and not contents.endswith("\n"):
                # A valid last JSON record may have survived without its newline.
                # Ensure the next appended record cannot concatenate onto it.
                with Path(path).open("a", encoding="utf-8") as stream:
                    stream.write("\n")
        answers = []
        started, reused = time.monotonic(), 0
        progress = getattr(self, "progress", None)
        if progress:
            progress.phase("GSM8K answer generation (not prompt preparation)", len(requests), "answers")
        print(f"GSM8K generation: starting {len(requests)} requests; {len(cache)} saved answers available", flush=True)
        for index, request in enumerate(requests, 1):
            self.current_doc = int(request.doc_id)
            if progress:
                progress.detail(current_doc_id=self.current_doc, current_generation_steps=0)
            signature = json.dumps([self.current_doc, request.args], sort_keys=True, default=str)
            key = hashlib.sha256(signature.encode()).hexdigest()
            if key in cache:
                record = cache[key]
                self.generation_records[self.current_doc] = record["metadata"]
                answers.append(record["answer"])
                reused += 1
            else:
                generated = super().generate_until([request], disable_tqdm=True)
                if len(generated) != 1:
                    raise RuntimeError("Expected one greedy answer per generation request.")
                answers.extend(generated)
                record = {"key": key, "doc_id": self.current_doc, "answer": generated[0],
                          "metadata": self.generation_records[self.current_doc]}
                if path:
                    Path(path).parent.mkdir(parents=True, exist_ok=True)
                    with Path(path).open("a", encoding="utf-8") as stream:
                        stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                cache[key] = record
            if progress:
                fresh = index-reused
                elapsed = time.monotonic()-started
                progress.advance(index, cache_reused=reused,
                                 last_answer_tokens=self.generation_records[self.current_doc]["generated_tokens"],
                                 remaining_seconds_estimate=(len(requests)-index)*elapsed/fresh if fresh >= 3 else None)
            elif index == 1 or index % 25 == 0 or index == len(requests):
                print(f"GSM8K generation: {index}/{len(requests)} completed; {reused} reused; elapsed {time.monotonic()-started:.0f}s", flush=True)
        return answers

    def loglikelihood(self, requests, disable_tqdm=False):
        progress = getattr(self, "progress", None)
        if not progress:
            return super().loglikelihood(requests, disable_tqdm=disable_tqdm)
        progress.phase(f"{getattr(self, 'active_task', 'benchmark')} candidate-likelihood scoring",
                       len(requests), "candidate scores")
        result = []
        for start in range(0, len(requests), 64):
            result.extend(super().loglikelihood(requests[start:start+64], disable_tqdm=True))
            progress.advance(min(start+64, len(requests)))
        return result

    def _model_generate(self, context, max_length, stop, **kwargs):
        progress = getattr(self, "progress", None)
        handle = None
        steps = 0
        if progress:
            def observed_forward(module, inputs, output):
                nonlocal steps
                steps += 1
                # Observe completed forward calls; do not change tokens or stopping rules.
                progress.detail(current_generation_steps=steps)
            handle = self.model.register_forward_hook(observed_forward)
        try:
            tokens = super()._model_generate(context, max_length, stop, **kwargs)
        finally:
            if handle is not None:
                handle.remove()
        continuation = tokens[0, context.shape[1]:].tolist()
        raw = self.tokenizer.decode(continuation, skip_special_tokens=False)
        eos = self.model.generation_config.eos_token_id
        eos = set(eos if isinstance(eos, list) else [eos])
        stopped = (bool(continuation) and continuation[-1] in eos) or any(s and s in raw for s in stop)
        self.generation_records[self.current_doc] = {
            "generated_tokens": len(continuation),
            "hit_token_cap": tokens.shape[1] >= max_length,
            "truncated": tokens.shape[1] >= max_length and not stopped,
            "raw_response": raw,
        }
        return tokens


def evaluation_model(c, root, method, update):
    tokenizer = load_tokenizer(root)
    if method == "baseline":
        return load_base(c, root).eval(), tokenizer
    run = Path(root) / "runs" / method
    if method in ("full_ft", "l2sp"):
        model = load_base(c, root)
        state = torch.load(run / "checkpoints" / f"update_{update:04d}.pt", map_location="cpu", weights_only=False)
        restore_trainable(model, state["model"])
        del state
        return model.eval(), tokenizer

    exports = torch.load(run / f"adapters_{update:04d}.pt", weights_only=True)
    # Check the exported effective (already projected) factors against their merged form.
    unmerged = attach_adapters(load_base(c, root), "lora4" if method == "lora4" else "lora16", c, root)
    with torch.no_grad():
        for name, item in exports.items():
            module = unmerged.get_submodule(name)
            module.A.copy_(item["A"].to("cuda"))
            module.B.copy_(item["B"].to("cuda"))
    unmerged.eval()
    merged = merge_into_fresh(load_base(c, root), exports).eval()
    probe_rows = read_jsonl(Path(root) / "prepared/probes.jsonl")
    differences = []
    relative = []
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.float16):
        # Math and non-math prompts, using actual exported factors.
        for row in [probe_rows[0], probe_rows[-1]]:
            inputs = tokenizer(row["prompt"], return_tensors="pt", add_special_tokens=False).to("cuda")
            a = unmerged(**inputs, logits_to_keep=1).logits[:, -1].float()
            b = merged(**inputs, logits_to_keep=1).logits[:, -1].float()
            differences.append((a - b).abs().max().item())
            relative.append(((a - b).norm() / (a.norm() + 1e-8)).item())
    destination = Path(root) / "evaluations" / f"{method}_{update:04d}"
    write_json(destination / "merge_check.json", {
        "max_abs_logit_differences": differences, "relative_l2_errors": relative,
        "relative_l2_tolerance": 0.02,
        "note": "FP16 merge changes rounding; inspect saved errors as well as threshold.",
    })
    if max(relative) > 0.02:
        raise ValueError("Merged/unmerged logits differ substantially. Inspect merge_check.json.")
    del unmerged, exports
    gc.collect()
    torch.cuda.empty_cache()
    return merged, tokenizer


def evaluate(c, root, method, update, smoke=False, progress=None):
    from lm_eval import simple_evaluate
    seed_all(c["seed"])
    destination = Path(root) / "evaluations" / f"{method}_{update:04d}"
    destination.mkdir(parents=True, exist_ok=True)
    if (destination / "complete.json").exists():
        if progress:
            progress.phase("already complete; reusing evaluation")
        return
    started = time.perf_counter()
    if progress:
        progress.phase("loading evaluation model")
    model, tokenizer = evaluation_model(c, root, method, update)
    model.config.use_cache = True
    if not smoke and method != "baseline":
        if progress:
            progress.phase("exporting standalone inference model")
        export = Path(root) / "models" / f"{method}_{update:04d}"
        # Save ordinary Hugging Face models so downloads do not require recovery
        # optimizer states or this custom adapter implementation for inference.
        model.save_pretrained(export, safe_serialization=True)
        tokenizer.save_pretrained(export)
        write_json(export / "export_complete.json", {
            "method": method, "update": update, "dtype": "float16",
            "format": "standalone Hugging Face model; projected adapters already merged",
        })
    wrapper = LoggedHFLM(
        pretrained=model, tokenizer=tokenizer, batch_size=c["eval_batch_size"],
        enable_thinking=False, max_length=model.config.max_position_embeddings,
    )
    wrapper.generation_cache_path = destination / "gsm8k_generation_progress.jsonl"
    wrapper.progress = progress
    all_scores = {}
    expected = {"gsm8k_cot": 1319, "hellaswag": 10042, "boolq": 3270, "arc_easy": 2376}
    for task, chat in [("gsm8k_cot", True), ("hellaswag", False), ("boolq", False), ("arc_easy", False)]:
        tasks = [task]
        wrapper.active_task = task
        result_path = destination / f"harness_{task}.json"
        samples_path = destination / f"{task}_samples.jsonl"
        if result_path.exists() and samples_path.exists():
            from .common import read_json
            cached = read_json(result_path)
            sample_ids = {row["doc_id"] for row in read_jsonl(samples_path)}
            if len(sample_ids) == (2 if smoke else expected[task]):
                all_scores.update(cached["results"])
                print(f"[REUSE] Completed {task} scores and per-example outputs", flush=True)
                continue
        if progress:
            progress.phase(f"preparing {task} prompts/requests (generation has not finished)")
        kwargs = dict(
            model=wrapper, tasks=tasks, num_fewshot=0, batch_size=c["eval_batch_size"],
            apply_chat_template=chat, log_samples=True,
            random_seed=c["seed"], numpy_random_seed=c["seed"],
            torch_random_seed=c["seed"], fewshot_random_seed=c["seed"],
            limit=2 if smoke else None,
        )
        if chat:
            kwargs["gen_kwargs"] = "max_gen_toks=32,do_sample=False" if smoke else "max_gen_toks=1024,do_sample=False"
        result = simple_evaluate(**kwargs)
        if result is None:
            raise RuntimeError("Evaluation harness returned no results.")
        for task, samples in result.pop("samples").items():
            doc_ids = {row["doc_id"] for row in samples}
            if not smoke and len(doc_ids) != expected[task]:
                raise ValueError(f"{task}: expected complete split ({expected[task]}), got {len(doc_ids)}")
            if task == "gsm8k_cot":
                for row in samples:
                    row.update(wrapper.generation_records[int(row["doc_id"])])
                    # Stock filtered_resps is the authoritative extracted answer.
                    row["extracted_answer"] = row.get("filtered_resps")
            write_jsonl(destination / f"{task}_samples.jsonl", samples)
        all_scores.update(result["results"])
        write_json(result_path, result)
        write_json(destination / "scores_partial.json", {"method": method, "results": all_scores,
                                                        "complete": len(all_scores) == 4})
    write_json(destination / "scores.json", {
        "method": method, "update": update, "smoke_only": smoke, "results": all_scores,
    })

    qualitative = []
    rows = qualitative_inputs(c)
    cap = 32 if smoke else 512
    existing = read_jsonl(destination / "qualitative.jsonl") if (destination / "qualitative.jsonl").exists() else []
    saved = {r["source_id"]: r for r in existing if r.get("generation_cap") == cap}
    if progress:
        progress.phase("qualitative response generation", len(rows), "responses")
    for index, row in enumerate(rows, 1):
        if row["source_id"] in saved and saved[row["source_id"]].get("messages") == row["messages"]:
            qualitative.append(saved[row["source_id"]])
            if progress:
                progress.advance(index, reused=True)
            continue
        if progress:
            progress.detail(question_id=row["source_id"])
        prompt = tokenizer.apply_chat_template(
            row["messages"], tokenize=False,
            add_generation_prompt=True, enable_thinking=False,
        )
        inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False).to("cuda")
        with torch.inference_mode():
            tokens = model.generate(**inputs, do_sample=False, max_new_tokens=cap,
                                    pad_token_id=tokenizer.pad_token_id)
        continuation = tokens[0, inputs.input_ids.shape[1]:].tolist()
        eos = model.generation_config.eos_token_id
        eos = set(eos if isinstance(eos, list) else [eos])
        qualitative.append({**row, "condition": f"{method}_{update:04d}",
                            "generation_cap": cap,
                            "response": tokenizer.decode(continuation, skip_special_tokens=True),
                            "generated_tokens": len(continuation),
                            "truncated": len(continuation) >= cap and continuation[-1] not in eos})
        write_jsonl(destination / "qualitative.jsonl", qualitative)
        if progress:
            progress.advance(index, last_answer_tokens=len(continuation))
    write_jsonl(destination / "qualitative.jsonl", qualitative)
    write_json(destination / "complete.json", {
        "evaluation_seconds": time.perf_counter() - started, "smoke_only": smoke,
    })


def verify_evaluation(c, root, progress):
    """Two short real-model generations plus resume/scoring checks; not assignment evidence."""
    from lm_eval.api.instance import Instance
    progress.phase("loading existing starting model for quick evaluation preflight")
    model, tokenizer = evaluation_model(c, root, "baseline", 0)
    wrapper = LoggedHFLM(pretrained=model, tokenizer=tokenizer, batch_size=1,
                        enable_thinking=False, max_length=model.config.max_position_embeddings)
    wrapper.progress = progress
    wrapper.generation_cache_path = Path(root) / "evaluation_preflight/generations.jsonl"
    requests = []
    for i, question in enumerate(["What is 2 + 2? Give a short answer.", "Reply with the word hello."]):
        prompt = tokenizer.apply_chat_template([{"role": "user", "content": question}],
                  tokenize=False, add_generation_prompt=True, enable_thinking=False)
        requests.append(Instance(request_type="generate_until", doc={}, idx=0,
                        arguments=(prompt, {"max_gen_toks": 8, "do_sample": False,
                                            "until": ["<|im_end|>"]}), metadata=("preflight", i, 1)))
    answers = wrapper.generate_until(requests)
    # On repeat every answer must come from its durable per-answer cache.
    if wrapper.generate_until(requests) != answers:
        raise RuntimeError("Cached generation differed from its saved answer.")
    wrapper.active_task = "preflight"
    likelihood = Instance(request_type="loglikelihood", doc={}, idx=0,
                          arguments=("The answer is", " four"), metadata=("preflight", 0, 1))
    result = wrapper.loglikelihood([likelihood])
    write_json(Path(root) / "evaluation_preflight/complete.json", {
        "passed": True, "answers": answers, "likelihood": result,
        "note": "Only two eight-token outputs; not benchmark results or a runtime estimate.",
    })
    print("EVALUATION PREFLIGHT PASSED: generation, progress, per-answer saves, resume, and likelihood scoring.", flush=True)
